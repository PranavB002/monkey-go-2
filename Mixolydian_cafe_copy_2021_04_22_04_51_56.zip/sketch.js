//initiate Game STATEs
var PLAY = 1;
var END = 0;
var gameState = PLAY;

//create a monkey sprite
var mo, image  = createSprite(200,380,20,50);
mo.loadAnimation("mo");

//set collision radius for the mo
mo.setCollider("circle",0,0,30);

//scale and position the mo
mo.scale = 0.2;
mo.x = 50;

//create a ground sprite
var ground = createSprite(200,380,400,20);
groundimage=loadImage("");
ground.x = ground.width /2;
ground.scale= 0.1;

//invisible Ground to support monkey
var invisibleGround = createSprite(200,385,400,5);
invisibleGround.visible =true;

//create Obstacle and Cloud Groups
var ObstaclesGroup = createGroup();

//place gameOver and restart icon on the screen
var gameOver = createSprite(200,300);
var restart = createSprite(200,340);
gameOver.setAnimation("GO");
gameOver.scale = 0.5;
restart.setAnimation("re");
restart.scale = 0.5;

gameOver.visible = false;
restart.visible = false;

//set text
textSize(18);
textFont("Georgia");
textStyle(BOLD);

//score
var count = 0;

function draw() {
  //set background to white
  background("white");
  //display score
  text("Score: "+ count, 250, 100);
  console.log(gameState);
  
  if(gameState === PLAY){
    //move the ground
    ground.velocityX = -(6 + 3*count/100);
    //sc`oring`
    count = count+Math.round(World.frameRate/30);
    
    if (count>0 && count%100 === 0){
      playSound("checkPoint.mp3");
    }
    
    if (ground.x < 0){
      ground.x = ground.width/2;
    }
    
     //jump when the space key is pressed
    if(keyDown("space") && mo.y >= 359){
      mo.velocityY = -12 ;
      playSound("jump.mp3");
    }
  
    //add gravity
    mo.velocityY = mo.velocityY + 0.8;
    
  
    //spawn obstacles
    spawnObstacles();
    
    //End the game when trex is touching the obstacle
    if(ObstaclesGroup.isTouching(mo)){
      playSound("jump.mp3");
      gameState = END;
      playSound("die.mp3");
    }
  }
  
  else if(gameState === END) {
    gameOver.visible = true;
    restart.visible = true;
    
    //set velcity of each game object to 0
    ground.velocityX = 0;
    mo.velocityY = 0;
    ObstaclesGroup.setVelocityXEach(0);
    
    //change the mo animation
    mo.setAnimation("mo");
    
    //set lifetime of the game objects so that they are never destroyed
    ObstaclesGroup.setLifetimeEach(-1);
   
    
    
  }
  
  if(mousePressedOver(restart)) {
    reset();
  }
  
  //console.log(trex.y);
  
  //stop trex from falling down
  mo.collide(invisibleGround);
  
  drawSprites();
}

function reset(){
 gameState=PLAY; 
 gameOver.visible=false;
 restart.visible=false;
 ObstaclesGroup.destroyEach();
 count=0;
 
 
 
 
 
 
 
 
 
 
 
 
}

function spawnObstacles() {
  if(World.frameCount % 60 === 0) {
    var obstacle = createSprite(400,365,10,40);
    obstacle.velocityX = - (6 + 3*count/100);
    
    //generate random obstacles
    var rand = randomNumber(1,4);
    obstacle.setAnimation("St");
    
      
    obstacle.scale = 0.1;
    obstacle.lifetime = 70;
    //add each obstacle to the group
    ObstaclesGroup.add(obstacle);
  }
}



